# ViewMaintenance Manager Record by Group

## Endpoints
- TEST: https://apvrt80538.uhc.com/services/maintenance/api/v1/recordsByGroup
- STAGE: (Coming Soon)
- PROD: https://interlink-dat.optum.com/services/maintenance/api/v1/recordsByGroup

## Method
Get

## Response
```
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<groups>
    <group name="ASI">
        <active>
            <record>
                <rdname>TestAgain</rdname>
                <change>0</change>
            </record>
        </active>
        <waiting/>
    </group>
    <group name="ASI_Test">
        <active>
            <record>
                <rdname>Policy_Test_9</rdname>
                <change>CHG1234567</change>
            </record>
        </active>
        <waiting/>
    </group>
</groups>
```
