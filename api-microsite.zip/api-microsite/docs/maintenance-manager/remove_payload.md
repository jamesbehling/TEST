# Remove Record API

```
action=<SR>
  <gpname>ASI</gpname>
  <rdname>record_name</rdname>
  <stoppedby>user_ms_id</stoppedby>
</SR>
```
