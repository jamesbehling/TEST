# Get Record API

## Endpoints
- TEST: https://apvrt80538.uhc.com/services/maintenance/api/v1/records
- STAGE: (Coming Soon)
- PROD: https://interlink-dat.optum.com/services/maintenance/api/v1/records

## Method
Get

## Parameters
- GroupName - Name of the grup to lookup (required)
- RecordName - Name of the record to lookup (required)

## Response
```
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<record>
    <gpname>ASI</gpname>
    <rdname>TestAgain</rdname>
    <class>BLACKOUT</class>
    <status>ACTIVE</status>
    <action>HIDE</action>
    <stype>MANUAL</stype>
    <etype>MANUAL</etype>
    <sdate>2021/07/23 10:22:06.114</sdate>
    <edate></edate>
    <selname>User initiated</selname>
    <selgroup>N/A</selgroup>
    <selector>alertId == '0000045651'</selector>
    <startedon>2021/07/23 10:22:06.114</startedon>
    <startedby>ppadmin@10.0.9.10:0.0</startedby>
    <endat></endat>
    <change>0</change>
</record>
```
