# Maintenance Manager API Payload Attributes

## gpname
- Group Name
- Default "ASI"
- Can be a short application name or team name

## rdname
- Record Name
- Can be an application name or server name for which event suppression is needed

## change
- ServiceNow change record that contains the related CIs (server or application)
- This field cannot be blank
- If there is no ServiceNow Change record, enter in a unique name

## sdate
- start date
- format YYYY/MM/DD HH:MM:SS

## edate
- start date
- format YYYY/MM/DD HH:MM:SS

## action (See here for action details)
- CLOSE: Closes or suppresses ALL ACTIVE events matching the event suppression criteria (including related ServiceNow notifications), state of all events will be CLOSED during the maintenance window (recommended)
- HIDE: Hides ALL events matching the event suppression criteria from Event Dashboard during the maintenance window, state of all events will be ACTIVE
- HIDENEW: Hides ONLY new events that occur during the duration of the maintenance window, state of new events will be ACTIVE
- HIDECLOSE: Hides ALL events matching the event suppression criteria from Event Dashboard during the maintenance window, state of all events will be CLOSED
- CLOSENEW: Closes or suppresses ONLY the latest ACTIVE events that occur during the maintenance window (including ServiceNow notifications), state of new events during window will be CLOSED.  ACTIVE events prior to the window will remain ACTIVE 

## etype
- AUTO
