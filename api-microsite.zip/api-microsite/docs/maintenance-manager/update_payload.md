# Update Maintenance Manager Record

```
action=<AR>
  <gpname>ASI</gpname>
  <rdname>Server_Patching</rdname>
  <edate>2021/07/25 16:10:00</edate>
  <sdate>2021/07/25 14:00:00</sdate>
  <duration></duration>
  <alterby>user ms id</alterby>
</AR>
```
