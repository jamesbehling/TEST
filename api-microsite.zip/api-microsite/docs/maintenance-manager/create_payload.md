# Create Record

## Endpoints
- TEST: https://apvrt80538.uhc.com/services/maintenance/api/v1/record
- STAGE: (Coming Soon)
- PROD: https://interlink-dat.optum.com/services/maintenance/api/v1/record

## Method
POST

## Headers
Context-Type: application/x-www.form-urlencoded

## data-urlencode
Key: action
Value: <payload> see examples below

<hr>

### Create Record API Payload Examples

### Sample payload to suppress events from multiple servers

```
<NR>
  <gpname>ASI</gpname>
  <rdname>Test_mm_record_</rdname>
  <change>CHG0000120</change>
  <sdate>2021/12/22 22:00:00</sdate>
  <edate>2021/12/22 22:10:00</edate>
  <action>CLOSE</action>
  <etype>AUTO</etype>
  <selector>
  <sel>{s1}</sel>
      <sel>_domain eq nw6s-ply-con02</sel>
  <sel>{s2}</sel>
      <sel>_domain eq nw6s-ply-con03</sel>
  <sel>{s3}</sel>
      <sel>_domain eq nw6s-ply-con04</sel>
  </selector>
  <startedby>puppet</startedby>
</NR>
```

### Sample payload to suppress an event based on application name

```
<NR>
  <gpname>ASI</gpname>
  <rdname>Test_Server_Patching</rdname>
  <change>CHG0000100</change>
  <sdate>2021/07/25 22:00:00</sdate>
  <edate>2021/07/25 23:00:00</edate>
  <action>CLOSE</action>
  <etype>AUTO</etype>
  <selector>
    <sel>{s1}</sel>
      <sel>_application eq Test_App</sel>
  <sel>{s1}</sel>
  </selector>
  <startedby>puppet</startedby>
</NR>
```

### Sample payload to suppress an event based on server name AND application name

```
<NR>
  <gpname>ASI</gpname>
  <rdname>Test_Server_Patching</rdname>
  <change>CHG0000100</change>
  <sdate>2021/07/25 22:00:00</sdate>
  <edate>2021/07/25 23:00:00</edate>
  <action>CLOSE</action>
  <etype>AUTO</etype>
  <selector>
    <sel>{s1}</sel>
      <sel>_domain eq apsrt4334</sel>
      <sel>AND</sel>
      <sel>_application eq CIRRUS/sel>
  <sel>{s1}</sel>
  </selector>
  <startedby>puppet</startedby>
</NR>
```

### Sample payload to suppress an event based on server name and text contains CPU is in error

```
<NR>
  <gpname>ASI</gpname>
  <rdname>Test_Server_Patching</rdname>
  <change>CHG0000100</change>
  <sdate>2021/07/25 22:00:00</sdate>
  <edate>2021/07/25 23:00:00</edate>
  <action>CLOSE</action>
  <etype>AUTO</etype>
  <selector>
    <sel>{s1}</sel>
      <sel>_domain eq apsrt4334</sel>
    <sel>{s2}</sel>
      <sel>text eq %CPU is in error%</sel>
  </selector>
  <startedby>puppet</startedby>
</NR>
```
