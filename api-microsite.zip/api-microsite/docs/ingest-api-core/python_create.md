# Sample payload using Python
Run the following command on your server to download the OPTUM Standard Trusts Cert
```
- curl https://repo1.uhc.com/artifactory/UHG-certificates/standard_trusts.pem > /etc/ssl/certs/standard_trusts.pem
- curl https://repo1.uhc.com/artifactory/UHG-certificates/optum/optum_ca1_full_chain.pem > /etc/ssl/certs/optumcabundle.pem
- curl https://repo1.uhc.com/artifactory/UHG-certificates/optum/optum_ca2_full_chain.pem >> /etc/ssl/certs/optumcabundle.pem
```
Copy the following to a python script and edit.
```
import requests

url = "<Event API Endpoint>"

payload = "{\r\n   \"OPTUM-API-TOKEN\": \"XXXXXXXXXXXXXXXXXXXX\",\r\n   \"event\": {\r\n      \"application\": \"<application>\",\r\n      \"object\": \"<object>\",\r\n      \"category\": \"<application>\",\r\n      \"severity\": \"<severity>\",\r\n      \"domain\": \"<domain>\",\r\n      \"title\": \"<title>\",\r\n      \"description\": \"<description>\",\r\n      \"origin\": \"<origin>\",\r\n      \"stateful\": \"<true|false>\"\r\n   }\r\n}"

headers = {'Content-Type': 'text/plain'}

response = requests.request("POST", url, headers=headers, data = payload, verify = "/etc/ssl/certs/standard_trusts.pem")

print(response.text.encode('utf8'))
```

# Sample payload for auto incident creation in ServiceNow using Python
Run the following command on your server to download the OPTUM Standard Trusts Cert
```
curl https://repo1.uhc.com/artifactory/UHG-certificates/standard_trusts.pem > /etc/ssl/certs/standard_trusts.pem
curl https://repo1.uhc.com/artifactory/UHG-certificates/optum/optum_ca1_full_chain.pem > /etc/ssl/certs/optumcabundle.pem
curl https://repo1.uhc.com/artifactory/UHG-certificates/optum/optum_ca2_full_chain.pem >> /etc/ssl/certs/optumcabundle.pem
```
Copy the following to a python script and edit.
```
import requests

url = "<Event API Endpoint>"

payload = "{\r\n   \"OPTUM-API-TOKEN\": \"<xxxxxxxxxxxxxxxxxx>\",\r\n   \"event\": {\r\n      \"application\": \"<application>\",\r\n      \"object\": \"<object>\",\r\n      \"category\": \"<application>\",\r\n      \"severity\": \"<severity>\",\r\n      \"domain\": \"<domain>\",\r\n      \"title\": \"<title>\",\r\n      \"description\": \"<description>\",\r\n      \"origin\": \"<origin>\",\r\n      \"stateful\": \"<true|false>\"\r\n    },\r\n    \"incident\": {\r\n        \"workgroup\": \"<ServiceNow workgroup name>\"\r\n    }\r\n}"

headers = {'Content-Type': 'text/plain'}

response = requests.request("POST", url, headers=headers, data = payload, verify = "/etc/ssl/certs/standard_trusts.pem")

print(response.text)
```
