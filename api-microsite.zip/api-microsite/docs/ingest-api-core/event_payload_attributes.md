# Standard Event Attributes
## Event
* **application**:<br>
Name of the Business Service, as defined in ServiceNow and ASK.  If auto-ticketed, will show in ServiceNow "reference 2" field.
* **object**:<br>
Object identifies what’s being monitored – Apache, JVM, CPU etc.  If auto-ticketed, will show in ServiceNow "reference 4" field.
* **category**:<br>
Default for application specific monitoring is “Application”.  Do not override the default unless you are using a valid Category. Common examples include – Application, Network, Database etc.  If auto-ticketed, will show in ServiceNow "reference 3" field.
* **severity**:<br>
Severity of the event. Valid values: Normal, Warning, Minor, Major, Critical.	For Alert definitions and down stream flows, please see the [Alert Definitions and Flow](https://uhgazure.sharepoint.com/:p:/r/sites/monitoring/Shared%20Documents/Operations-Bridge-Manager/Enterprise%20Monitoring%20Events%20Process.pptx?d=w221a5679e0c54f1a8095bbf378a8e496&csf=1&web=1&e=0V4u5b) document.  If auto-ticketed, will show in ServiceNow "priority" field.
* **domain**:<br>
The host name of the system that is being monitored.  If auto-ticketed, will show in ServiceNow "machine name" field.
* **title**:<br>
Title or message text or alert text.  If auto-ticketed, will show in ServiceNow "short description" and "description" field.
* **description**:<br>
Description of the event.  If auto-ticketed, will show in ServiceNow "description" field.
* **origin**:<br>
Hostname of Source Monitoring System or Application that’s doing the monitoring.
* **stateful**:<br>
Will the monitoring system send a normal event to acknowledge the return to normal of the non-normal event.
* **environment**:<br>
Environment of where the event is taking place in.
* **enclave_env**:<br>
The enclave of where the event is taking place in.  Example: OFE <default: blank><br>
  * If enclave = OFE, any Incidents created off the event will go to ServiceNow Gov.<br>
  * If enclave = OptumCare, any Incidents created off the event will go to ServiceNow OptumCare.<br>
  * If blank or any other value, any Incidents created off the event will go to ServiceNow Core.
* **sched_id**:<br>
Schedule Id
* **url**:<br>
A URL to a failed URL or link to another system if this event can be traced back
* **dashboard_uid**:<br>
The dashboard universal id if this event can be traced back
## Incident
* **workgroup**:<br>
Auto-Incident Only - The ServiceNow workgroup to assign the Incident to.
* **ci**:<br>
Auto-Incident Only - The host name of the server to be associated to the Incident. Optional
* **reference1**:<br>
Auto-Incident Only - The reference1 field on the Incident. Optional
* **reference2**:<br>
Auto-Incident Only - The reference2 field on the Incident. Optional
* **reference3**:<br>
Auto-Incident Only - The reference3 field on the Incident. Optional
* **reference4**:<br>
Auto-Incident Only - The reference4 field on the Incident. Optional
* **reference5**:<br>
Auto-Incident Only - The reference5 field on the Incident. Optional
* **reference6**:<br>
Auto-Incident Only - The reference6 field on the Incident. Optional
* **short_description**:<br>
Auto-Incident Only - The short description of the Incident. Optional
* **priority**:<br>
Auto-Incident Only - The priority of the Incident.  Valid values: 4, 3, 2, 1. Optional
* **incident_category**:<br>
Auto-Incident Only - The Incident category of the Incident.  Valid values: "Application/Service" (default), "Batch", "Business Equipment","Database","Desktop Related","Facilities","Network - Data","Network - Voice","Physical Security","Print/Fax","Security","Server","Storage","Vendor". Optional
* **incident_subcategory**:<br>
Auto-Incident Only - The Incident subcategory of the Incident.  Valid values: Blank (default), "Access", "Capacity", "Performance", "Software", "Hardware", "Certificate", "Procedural", "Other". Optional
