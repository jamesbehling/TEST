# Endpoints
- Test: http://apvrt80538.uhc.com:8088
- Stage: 
- Production: https://interlink-dat.optum.com:8088

# Sample payload
````
{
   "OPTUM-API-TOKEN": "<xxxxxxxxxxxxxxxxxx>",
   "event": {
      "application": "<FORMAL_NAME_IN_SERVICE_NOW>",
      "object": "<object>",
      "category": "<category>",
      "severity": "<severity>",
      "domain": "<fqdn>",
      "title": "<message text>",
      "description": "<description>",
      "origin": "<fqdn>",
      "stateful": "<true|false>",
      "environment":"<environment>",
      "enclave_env":"<enclave_env>",
      "sched_id":"<sched_id>",
      "url":"https://uhgazure.sharepoint.com/sites/Sparq-Online",
      "dashboard_uid":"12345"
    }
}
````

# Sample payload for auto incident creation in ServiceNow
````
{
   "OPTUM-API-TOKEN": "<xxxxxxxxxxxxxxxxxx>",
   "event": {
      "application": "<FORMAL_NAME_IN_SERVICE_NOW>",
      "object": "<object>",
      "category": "<category>",
      "severity": "<severity>",
      "domain": "<fqdn>",
      "title": "<message text>",
      "description": "<description>",
      "origin": "<fqdn>",
      "stateful": "<true|false>",
      "environment":"<environment>",
      "enclave_env":"<enclave_env>",
      "sched_id":"<sched_id>",
      "url":"https://uhgazure.sharepoint.com/sites/Sparq-Online",
      "dashboard_uid":"12345"
    },
    "incident": {
        "workgroup": "<YOUR_SUPPORT_WORKGROUP_IN_SERVICE_NOW>",
        "ci":"<ci>", (Optional)
        "reference1":"<reference1>", (Optional)
        "reference2":"<reference2>", (Optional)
        "reference3":"<reference3>", (Optional)
        "reference4":"<reference4>", (Optional)
        "reference5":"<reference5>", (Optional)
        "short_description":"<short_description>", (Optional)
        "priority":"<4, 3, 2, 1>", (Optional)
        "incident_category":<"Application/Service", "Batch", "Business Equipment","Database","Desktop Related","Facilities","Network - Data","Network - Voice","Physical Security","Print/Fax","Security","Server","Storage","Vendor">,  (Optional)
        "incident_subcategory":<"Access", "Capacity", "Performance", "Software", "Hardware", "Certificate", "Procedural", "Other"> (Optional)
    }
}
````
