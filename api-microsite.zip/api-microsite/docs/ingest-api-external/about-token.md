# API Token
The external event API requires two API tokens to be passed with each request:
 - Bearer Token - Required in the request header for API Gateway Authorization allowing event data into the OPTUM network. This token must be prefixed by “Bearer “ with the space between Bearer and the token as follows: Bearer
 - Interlink Token - (OPTUM-EXT-API-TOKEN) - Required in the request body for Interlink Authorization.

## Request API Token
Submit an [Enterprise Monitoring service request](http://goto.optum.com/monitoring/request).

### Request details:
- Select Add, modify, remove existing monitor request type
- Specify the name of the Business Service (as defined in ASK) that the events are going to be related to
- Specify the Source Monitoring System that will be generating these events (if applicable)
- Indicate that you would like to have a Bearer token and API token created for generating events in Interlink
- Specify a technical contact (name, email address, and phone number)
