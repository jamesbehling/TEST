# API Token
The Event API requires an API token to be passed with each request. You can pass this token in the payload as shown in the Sample Payloads section below.

## Request API Token
please submit an [Enterprise Monitoring service request](http://goto.optum.com/monitoring/request).

### Request details:
- Select Add, modify, remove existing monitor request type
- Specify the name of the Business Service (as defined in ASK) that the events are going to be related to
- Specify the Source Monitoring System that will be generating these events (if applicable)
- Indicate that you would like to have an API token created for generating events in Interlink
- Specify a technical contact (name, email address, and phone number)
