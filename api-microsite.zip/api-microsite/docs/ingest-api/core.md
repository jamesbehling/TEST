## Hey there 👋
This is the core page

Edit `docs/ingest-api/core.md` to update this page

Welcome1
