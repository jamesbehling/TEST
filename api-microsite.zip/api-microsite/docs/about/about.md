---
id: about
title: About
---

## Problem Statement

With the complexity of OPTUM, UnitedHealth Group and it's subsitiaries, the computing environment spans 1,000s of devices, both physical and virtual, in-house and cloud hosted.  With so many monitoring sources out there monitoring different aspects of the environment, it is difficult to find out 

## Our Solution

Interlink is OPTUMs perfered tool for Event Management.  It receives events from multiply tools, multiple environments, multiple regions, both internal and external to OPTUM using standards like an open REST API or Messaging Queue like Kafka.

## Vision

_Consume, normalize, enrich and share events from the corporation to all that can use the data._

## Mission



## Tech Stack


Branch10.1
